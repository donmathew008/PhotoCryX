                          To plot epsilon in 2D
                          
(Actually it is 3D but as of now 3D visualisation is not possible using python interface)

                          To plot epsilon in 3D

# Install Mayavi or vis5d to visualise in 3D 
                          
# We have "band-epsilon.h5" in our folder

# Now open a terminal at the location and run (change the numbers "06")

	mpb-data -m 2 -r -n 32 band-epsilon.h5 band-dpwr.k06.b*.h5
                                                                                   
	h5tov5d -o diamond.v5d -d data-new band-epsilon.h5 band-dpwr.k06.b*.h5
	
# Sometimes the library is not found then 

	export LD_LIBRARY_PATH=/usr/local/hdf5/lib/:$LD_LIBRARY_PATH  
	
# If HDF5 error pops up export the following and run the above 

	export HDF5_USE_FILE_LOCKING=FALSE	
	
# To view using vis5d (Recommended)
                                                                                   
	vis5d diamond.v5d &
	
# To view in Mayavi, execute 

	python plot3d.py
	
